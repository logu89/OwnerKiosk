﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;

// Reference path for the following assemblies --> C:\Program Files\Microsoft Expression\Encoder 4\SDK\
using Microsoft.Expression.Encoder.Devices;
using Microsoft.Expression.Encoder.Live;
using Microsoft.Expression.Encoder;
using System.IO;
using System.Net;
using System.Threading;

namespace EE4Test
{
    public partial class frmEE4WebCam : Form
    {
        [DllImport("user32.dll")]
        static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);
        int ist1started = 0;
        int isuploadGoing = 0;
        int wcnt = 0;
        string cur_upl_file = "";
        DateTime last_alert_time;
        public frmEE4WebCam()
        {
            InitializeComponent();
            last_alert_time = DateTime.Now;
            this.WindowState = FormWindowState.Maximized;
            ThreadSafeDelegate(delegate
     {
         if (Directory.Exists(@"D:\\frames"))
         {
             Directory.Delete(@"D:\\frames", true);
         }
         timer2.Interval = 13000;
         timer2.Start();
         Process p = Process.Start(@"C:\Program Files (x86)\Free2X\Webcam Recorder\WebcamRecorder.exe");
         Thread.Sleep(1000); // Allow the process to open it's window
         //   Application.DoEvents();
         SetParent(p.MainWindowHandle, panel1.Handle);
         Directory.CreateDirectory(@"D:\\frames");
         this.SendToBack();
     });
        }
        // Thread-safe operations from event handlers        
        public void ThreadSafeDelegate(MethodInvoker method)
        {
            if (InvokeRequired)
                BeginInvoke(method);
            else
                method.Invoke();
        }
        private void frmEE4WebCam_Load(object sender, EventArgs e)
        {

        }

        private void btnPreview_Click(object sender, EventArgs e)
        {


        }

        public DateTime getDateTimeFromName(string name)
        {
            string[] datesarr = name.Split('_');
            string datestr = datesarr[2] + "/" + datesarr[3] + "/" + datesarr[1] + " " + datesarr[4] + ":" + datesarr[5] + ":" + datesarr[6];
            DateTime time = DateTime.Parse(datestr);
            return time;
        }

        public static Bitmap ResizeImage(Bitmap imgToResize, Size size)
        {
            try
            {
                Bitmap b = new Bitmap(size.Width, size.Height);
                using (Graphics g = Graphics.FromImage((Image)b))
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.DrawImage(imgToResize, 0, 0, size.Width, size.Height);
                }
                return b;
            }
            catch
            {
                Console.WriteLine("Bitmap could not be resized");
                return imgToResize;
            }
        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                ThreadSafeDelegate(delegate
           {
               timer1.Stop();
               string strGrabFileName = "";
               // Create a Bitmap of the same dimension of panelVideoPreview (Width x Height)
               using (Bitmap bitmap = new Bitmap(980, 730))
               {
                   using (Graphics g = Graphics.FromImage(bitmap))
                   {
                       // Get the paramters to call g.CopyFromScreen and get the image
                       Rectangle rectanglePanelVideoPreview = panel1.Bounds;
                       rectanglePanelVideoPreview.Height = rectanglePanelVideoPreview.Height - 50;
                       rectanglePanelVideoPreview.Width = rectanglePanelVideoPreview.Width - 250;
                       Point sourcePoints = panel1.PointToScreen(new Point(panel1.ClientRectangle.X + 290, panel1.ClientRectangle.Y + 50));
                       g.CopyFromScreen(sourcePoints, Point.Empty, rectanglePanelVideoPreview.Size);
                   }

                   strGrabFileName = "D:\\frames\\Snapshot_" + getName(DateTime.Now) + ".png";
                   Size ss = new System.Drawing.Size();
                   ss.Height = 200;
                   ss.Width = 400;
                   using (Bitmap bitmap1 = ResizeImage(bitmap, ss))
                   {
                       //   toolStripStatusLabel1.Text = strGrabFileName;
                       bitmap1.Save(strGrabFileName, System.Drawing.Imaging.ImageFormat.Png);
                   }
               }

               if (isuploadGoing == 0)
               {
                   isuploadGoing = 1;
                   cur_upl_file = strGrabFileName;
                   // Read file data
                   FileStream fs = new FileStream(strGrabFileName, FileMode.Open, FileAccess.Read);
                   byte[] data = new byte[fs.Length];
                   fs.Read(data, 0, data.Length);
                   fs.Close();

                   // Generate post objects
                   Dictionary<string, object> postParameters = new Dictionary<string, object>();
                   postParameters.Add("action", "updateframe");
                   postParameters.Add("filename", Path.GetFileName(strGrabFileName));
                   postParameters.Add("filetype", "image");
                   postParameters.Add("file", new FormUpload.FileParameter(data, Path.GetFileName(strGrabFileName), "image/png"));

                   // Create request and receive response
                   string postURL = "http://mevintech.esy.es/ventura/index.php/api";
                   string userAgent = "Mozilla";
                   HttpWebResponse webResponse = FormUpload.MultipartFormDataPost(postURL, userAgent, postParameters);

                   // Process response
                   StreamReader responseReader = new StreamReader(webResponse.GetResponseStream());
                   string fullResponse = responseReader.ReadToEnd();
                   webResponse.Close();
                   isuploadGoing = 0;
                   cur_upl_file = "";
               }

               // File.Delete(strGrabFileName);
               Application.DoEvents();
               timer1.Start();
           });
            }
            catch (Exception ex)
            {
                timer1.Start();
                isuploadGoing = 0;
                cur_upl_file = "";
            }
        }
        Canny CannyData;

        public double bitMapDiff(Bitmap b1, Bitmap b2)
        {
            double res = 0;
            int tx = 0;
            int ty = 0;
            tx = b1.Width;
            ty = b1.Height;
            int diffcnt = 0;
            int cnt = 0;
            if (tx > b2.Width)
            {
                tx = b2.Width;
            }
            if (ty > b2.Height)
            {
                ty = b2.Height;
            }
            ty = ty - 50;

            for (int px = 0; px < tx; )
            {
                for (int py = 0; py < ty; )
                {
                    Color c1 = b1.GetPixel(px, py);
                    Color c2 = b2.GetPixel(px, py);
                    if (c1 != c2)
                    {
                        diffcnt++;
                    }
                    cnt++;
                    py = py + 1;
                }
                px = px + 1;
            }

            res = (double)((double)diffcnt / (double)cnt) * 100;

            return res;
        }

        public string getName(DateTime ctime)
        {
            return ctime.Year + "_" + ctime.Month + "_" + ctime.Day + "_" + ctime.Hour + "_" + ctime.Minute + "_" + ctime.Second;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            try
            {
                ThreadSafeDelegate(delegate
           {
               // timer3.Interval = 10000;
               //timer3.Start();
               timer2.Stop();
               if (ist1started == 0)
               {
                   wcnt = 1;
                   ist1started = 1;
                   timer1.Interval = 1000;
                   timer1.Start();
                   this.Text = "Started";
                   Application.DoEvents();
               }
               else
               {

                   this.Text = "Waiting..." + wcnt.ToString() + " ...";
                   Application.DoEvents();
                   wcnt++;

               }

               string[] files = System.IO.Directory.GetFiles(@"D:\\frames");
               int isObjectFound = 0;

               int cnt = 0;
               Bitmap prevBitmap = null;
               Bitmap currBitmap = null;
               Image ii = null;
               DateTime curtime = DateTime.Now;
               foreach (string file in files)
               {
                   DateTime time = getDateTimeFromName(Path.GetFileNameWithoutExtension(file));
                   TimeSpan ts = curtime - time;
                   TimeSpan alertts = curtime - last_alert_time;
                   if (ts.TotalSeconds < 6)
                   {
                       last_alert_time = DateTime.Now;
                       ii = Image.FromFile(file);
                       Application.DoEvents();
                       DateTime dt1 = new DateTime();
                       DateTime dt2 = new DateTime();
                       TimeSpan dt3 = new TimeSpan();
                       float TH, TL;
                       dt1 = DateTime.Now;
                       TH = 75;
                       TL = 25;
                       CannyData = new Canny((Bitmap)ii, TH, TL, 5, 1);
                       dt2 = DateTime.Now;
                       dt3 = dt2 - dt1;
                       currBitmap = CannyData.DisplayImage(CannyData.EdgeMap);
                       //pictureBox1.Image = ii;
                       Thread.Sleep(40);
                       Application.DoEvents();
                       if (cnt >= 1)
                       {
                           double diff = bitMapDiff(currBitmap, prevBitmap);
                           if (diff > 0.6)
                           {

                               WebClient wc = new WebClient();
                               wc.UseDefaultCredentials = true;
                               string response = wc.DownloadString("http://mevintech.esy.es/ventura/index.php/api/?action=alert");

                               if (response != null)
                               {
                                   isObjectFound = 1;
                                   break;
                               }
                               Application.DoEvents();
                           }
                           //   break;
                       }

                       prevBitmap = (Bitmap)currBitmap;
                       //MessageBox.Show(dt3.ToString());
                       //  Thread.Sleep(400);
                       cnt++;
                   }
               }
               if (isObjectFound == 1)
               {
                   currBitmap.Dispose();
                   prevBitmap.Dispose();
                   ii.Dispose();
                   currBitmap = null;
                   prevBitmap = null;
                   ii = null;
                   Application.DoEvents();
                   isObjectFound = 0;
                   this.Text = "Object Found";
                   Application.DoEvents();


                   Thread.Sleep(2000);
                   Application.DoEvents();
                   wcnt = 1;
                   this.Text = "Waiting...";
                   Application.DoEvents();
               }

               timer2.Interval = 1000;
               timer2.Start();

           });
            }
            catch (Exception ex)
            {
                wcnt = 1;
                this.Text = "Waiting..." + wcnt.ToString() + "  ...";
                Application.DoEvents();
                timer2.Start();
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            try
            {
                timer3.Stop();
                timer1.Stop();
                timer2.Stop();
                wcnt = 1;
                ist1started = 1;
                this.Text = "Deleting";
                Application.DoEvents();
                if (Directory.Exists(@"D:\\frames"))
                {

                    Directory.Delete(@"D:\\frames", true);
                }
                Directory.CreateDirectory(@"D:\\frames");
                timer3.Start();
                timer1.Start();
                timer2.Start();
            }
            catch
            {
                timer3.Start();
            }
        }

        private void frmEE4WebCam_FormClosing(object sender, FormClosingEventArgs e)
        {
            Process[] pp = Process.GetProcessesByName("WebcamRecorder.exe");
            foreach (Process p in pp)
            {
                p.Kill();
            }
        }

        private void frmEE4WebCam_FormClosed(object sender, FormClosedEventArgs e)
        {
            Process[] pp = Process.GetProcessesByName("WebcamRecorder.exe");
            foreach (Process p in pp)
            {
                p.Kill();
            }
        }

    }
    public static class FormUpload
    {
        private static readonly Encoding encoding = Encoding.UTF8;
        public static HttpWebResponse MultipartFormDataPost(string postUrl, string userAgent, Dictionary<string, object> postParameters)
        {
            string formDataBoundary = String.Format("----------{0:N}", Guid.NewGuid());
            string contentType = "multipart/form-data; boundary=" + formDataBoundary;

            byte[] formData = GetMultipartFormData(postParameters, formDataBoundary);

            return PostForm(postUrl, userAgent, contentType, formData);
        }
        private static HttpWebResponse PostForm(string postUrl, string userAgent, string contentType, byte[] formData)
        {
            HttpWebRequest request = WebRequest.Create(postUrl) as HttpWebRequest;

            if (request == null)
            {
                throw new NullReferenceException("request is not a http request");
            }

            // Set up the request properties.
            request.Method = "POST";
            request.ContentType = contentType;
            request.UserAgent = userAgent;
            request.UseDefaultCredentials = true;
            request.CookieContainer = new CookieContainer();
            request.ContentLength = formData.Length;

            // You could add authentication here as well if needed:
            // request.PreAuthenticate = true;
            // request.AuthenticationLevel = System.Net.Security.AuthenticationLevel.MutualAuthRequested;
            // request.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(System.Text.Encoding.Default.GetBytes("username" + ":" + "password")));

            // Send the form data to the request.
            using (Stream requestStream = request.GetRequestStream())
            {
                requestStream.Write(formData, 0, formData.Length);
                requestStream.Close();
            }

            return request.GetResponse() as HttpWebResponse;
        }

        private static byte[] GetMultipartFormData(Dictionary<string, object> postParameters, string boundary)
        {
            Stream formDataStream = new System.IO.MemoryStream();
            bool needsCLRF = false;

            foreach (var param in postParameters)
            {
                // Thanks to feedback from commenters, add a CRLF to allow multiple parameters to be added.
                // Skip it on the first parameter, add it to subsequent parameters.
                if (needsCLRF)
                    formDataStream.Write(encoding.GetBytes("\r\n"), 0, encoding.GetByteCount("\r\n"));

                needsCLRF = true;

                if (param.Value is FileParameter)
                {
                    FileParameter fileToUpload = (FileParameter)param.Value;

                    // Add just the first part of this param, since we will write the file data directly to the Stream
                    string header = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"{1}\"; filename=\"{2}\"\r\nContent-Type: {3}\r\n\r\n",
                        boundary,
                        param.Key,
                        fileToUpload.FileName ?? param.Key,
                        fileToUpload.ContentType ?? "application/octet-stream");

                    formDataStream.Write(encoding.GetBytes(header), 0, encoding.GetByteCount(header));

                    // Write the file data directly to the Stream, rather than serializing it to a string.
                    formDataStream.Write(fileToUpload.File, 0, fileToUpload.File.Length);
                }
                else
                {
                    string postData = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"{1}\"\r\n\r\n{2}",
                        boundary,
                        param.Key,
                        param.Value);
                    formDataStream.Write(encoding.GetBytes(postData), 0, encoding.GetByteCount(postData));
                }
            }

            // Add the end of the request.  Start with a newline
            string footer = "\r\n--" + boundary + "--\r\n";
            formDataStream.Write(encoding.GetBytes(footer), 0, encoding.GetByteCount(footer));

            // Dump the Stream into a byte[]
            formDataStream.Position = 0;
            byte[] formData = new byte[formDataStream.Length];
            formDataStream.Read(formData, 0, formData.Length);
            formDataStream.Close();

            return formData;
        }

        public class FileParameter
        {
            public byte[] File { get; set; }
            public string FileName { get; set; }
            public string ContentType { get; set; }
            public FileParameter(byte[] file) : this(file, null) { }
            public FileParameter(byte[] file, string filename) : this(file, filename, null) { }
            public FileParameter(byte[] file, string filename, string contenttype)
            {
                File = file;
                FileName = filename;
                ContentType = contenttype;
            }
        }
    }
}
